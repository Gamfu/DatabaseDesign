<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Responses</title>
<style type="text/css">
@import url("Register.css");
</style>
</head>

<body>
	<?php
	
	function SetupScripts(){
		if(file_exists("data"))
		{
			//do nothing
		}
		else{
			mkdir("data");
		}
		
		//storing information on unique users and posts
		if(file_exists("data/WarmingBook.txt"))
		{
			//do nothing
		}
		else{
		$newDatabase = fopen("data/WarmingBook.txt", "w");
		}
		
		//create a folder for comments if one doesn't already exist
		if(file_exists("comments"))
		{
			//do nothing
		}
		else{
		mkdir("comments");
		}
	}
	
	function displayNameRequired($fieldName){
		echo "<h3>A valid entry in the \"$fieldName\" field is required </h3>";
	}
	
	function validateInput($data, $fieldName){
		global $errorCount; //this is for counting how many times the user failed to input name
		
		if(empty($data)){
			displayNameRequired($fieldName);
			++$errorCount;
			$retval = "";
		} 
		else{
			$retval = trim($data);
			$retval = stripslashes($retval);
		}
		return($retval);
	}
	
	$errorCount = 0;
	$userName = validateInput($_POST["fullName"], "<b>Enter Name</b>");
	$email = filter_var($_POST["email"], FILTER_SANITIZE_EMAIL);
	$Dir = "data";
	$UserComments = $_POST["comment"];
	
	$EntryCount = 000;
	$emailCheck;
	$imgStore = $_POST["upload"];
	
	//variables for linking php server
	$severname = "localhost";
	$Susername = "gordonDefault";
	$password = "ScadSummer2020";
	$databaseName = "HouseWarming_Database";
	$date = date('Y/m/d');
	$time = date('h:i:sa');
	
	function ShowHomePage(){
		?>
		<p>
			<form action = "HouseWarmingBook.html">
			<input type="submit" value="Try Again?">	
			</form>
		</p>
		<?php
	}
	
	function UserComments()
	{
		$DirComment = "comments";
		if(is_dir($DirComment))
		{
				if(isset($_POST["save"]))
				{
					$SaveString = " Vistor unknown \n";
				}
				else
				{
					$SaveString = stripslashes($_POST['fullName']) . "\n";
					$SaveString .= date('r') . "\n";
					$SaveString .= stripslashes($_POST['comment']) . "\n";
					$CurrentTime = microtime();
					$TimeArray = explode(" " , $CurrentTime);
					$TimeStamp = (float)$TimeArray[1] + (float)$TimeArray[0];
				}

				$CommentFiles = scandir($DirComment,1);
				foreach ($CommentFiles as $FileName)
				{
					echo "<div id='commentScroll'>";
						if(($FileName != ".") && ($FileName != ".."))
						{
							//echo "From <strong> $FileName </strong><br>";
							echo "<pre> \n";
							$Comment = file_get_contents($DirComment . "/" . $FileName);
							echo $Comment;
							echo "</pre>\n";
							echo "<hr />\n";
						}	
					echo "</div>";
				}
		}
		
			$SaveFileName = "$DirComment/comments.$TimeStamp.txt";
		
			if(file_put_contents($SaveFileName,$SaveString) > 1)
			{
				//Do Nothing
				//echo "File \ " . htmlentities($SaveFileName) . "\" saved successfully.<br />\n" ;
			}
			else{
				echo "There was an error writing this file";
			}
		
	}
	
		function UpdateRegistry()
	{
		if(isset($_POST["Submit"]))
		{
			global $EntryCount;
			$RegisteryName = addslashes($_POST["fullName"]);
			$RegistryEmail = addslashes($_POST["email"]);
			$RegistryNumber = ++$EntryCount;

			$NewEntry = "$RegisteryName , $RegistryEmail , $RegistryNumber '\n' ";
			$EntryFile = "WarmingBook.txt";
			if(file_put_contents($EntryFile, $NewEntry, FILE_APPEND) > 1){
				//Do nothing
			}
			else{
				echo "Registration Error";
				}
			}
	}
	
		
	function Database()
	{	
			if(is_dir($Dir))
			{
				echo "<table border='1' width='100%'>\n";
				echo "<tr>
						<th>Date</th>
						<th>Time</th> 
						<th>Guest Name</th> 
						<th>E-mail Address</th> 
						<th>Guestbook Entry</th> 
					 </tr>";
				
				$DirEntries = scandir($Dir);
				foreach($DirEntries as $Entry){
					$EntryFullName = $Dir . "/" . $Entry;
					echo "<tr><td>" 
						. date("Y/m/d") . "</td><td>" 
						. date("h:i:sa") . "</td><td>"
						. $userName . "</td><td>"
						. $email . "</td><td>"
						. ++$EntryCount . "</td></tr>\n"; //suppose to be guestbook
		}
		echo "</table>\n";

		}
	}
	
	function StartContent()
	{	
		//Page that's displayed if no errors are present
		
		global $userName;
		global $UserComments;
		
		echo "<div id= 'Container'>";

			echo "<h1> Greetings, $userName</h1> <br>";
			echo "<h2> Thank you for signing up for Kevin's housewarming event</h2><br>";

			echo "<div id='response'>";

				echo "<h3> Hey <span style='color: #269492'>$userName</span>, here's what you said to Kevin: <br></h3>";
				echo "$UserComments ";

			echo "</div>";

			echo "<p> Check out what some of the others are saying below</p>";
			echo " <br> <hr/>";

		echo "</div>";


		ImageUpload();
		UpdateRegistry();
		
		
		echo "<div id=scrollWindow>";
			echo "<h2>Other Attendees Said:</h2>";
			UserComments();
		echo "</div>";
	
	}
	
		function ImageUpload()
		{
			/*
			//Second attempt at uploading file
			$targetDir = "images/";
			$targetFile = $targetDir . basename($_FILES["file"]["name"]);
			$uploadOk = true;
			$imageFileType = strtolower(pathinfo($targetFile,PATHINFO_EXTENSION));
			if(isset($_POST["Submit"]))
			{
				$Check = getimagesize($_FILES["file"]["tmp_name"]);
				if($Check !== false)
				{
					echo "File is an image - " . $Check["mine"] . ".";
					$uploadOk = 1;
				}
				else
				{
					echo "File is not a image";
					$uploadOk = 0;
				}
				
				if( $_FILES["file"]["size"] > 500000)
				{
					echo "Sorry this image is too large";
					$uploadOk = 0;
				}

				if($imageFileType != "jpg" || $imageFileType != "png" || $imageFileType != "jpeg" || $imageFileType != "gif")
				{
					echo "Sorry this file type is not supported";
					$uploadOk = 0;
				}
				else{
					
				}
				
				
				
				//First attempt at uploading a file
				
				$filePath = "images/" . $_FILES["file"]["name"];
				
				if(move_uploaded_file($_FILES["file"]["tmp_name"], $filePath))
				{
					echo "<img id='Img' src=" . $filePath. " />"; 	
				}
				else
				{
					echo "Aw, no image for you?";	
				}
				
			}
			*/
		}
	
	
	// Script action begins below
	
	SetupScripts();
	
		//Validate that email entered is writen in valid email syntax. This doesn't confirm that the email actually exists however. As a caveat, this is why most sites validate emails by sending a confirmation email, as that is a surefire way to confirm a user's email is accurate. Information on how to do this linked here : https://code.tutsplus.com/tutorials/how-to-code-a-signup-form-with-email-confirmation--net-6860
	
	
			//For some reason this script won't work if put into a function. Weird
				if (filter_var($email, FILTER_VALIDATE_EMAIL)){
					global $emailCheck;
					$emailCheck = true;
				}
	
				if (empty($email)){
					displayNameRequired("E-mail");
					++$errorCount;
				}
	
				else if (!empty($email)  && (!filter_var($email, FILTER_VALIDATE_EMAIL))){
					displayNameRequired("E-mail");
					++$errorCount;
				}
		
	if($errorCount > 0){
		//checks if the user failed to select a field, adds home button
		echo "Please use the \"Back\" button to re-enter the data";
		ShowHomePage();
	} 
	else{
		StartContent();
	}
	
	$conn = mysqli_connect($severname, $Susername, $password, $databaseName);
	
	if(!$conn){
		die("Connection failed: " . mysqli_connect_error());
	}
	
	echo "Connected Successfully";
	
	if(isset($_POST["Submit"]))
	{
		//$sql = "INSERT INTO RegistryTracker (Date,Time,GuestName,Email,Entry) VALUES ('$date', '$time',$userName','$email','$EntryCount')";
		$sql = "INSERT INTO RegistryTracker (Date,Time,Name,Email,Entry) VALUES ('$date', '$time','$userName','$email','++$EntryCount')";
		$result = $conn->query($sql);
		
		if($result === TRUE){
			echo "<br> Successfully uploaded the file";
		}
	}
	
	?>
	
</body>
</html>